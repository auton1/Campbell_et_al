This folder contains the genetic maps derived from 4,209 families, as described
in the manuscript, Campbell et al. (submitted).

Sex specific maps are provided in addition to sex-averaged maps.

Coordinates are in build 37.

Contact: Adam Auton (adam.auton@einstein.yu.edu)
Last updated: 20140827
